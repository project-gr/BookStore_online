# BookStore_online
Online bookstore system
SQL server
Database: BookStore
  username: sa
  password: sa
